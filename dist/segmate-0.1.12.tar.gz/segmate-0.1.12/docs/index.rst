.. include:: ../README.rst
   :start-after: start-in-sphinx-home-docs
   :end-before: end-in-sphinx-home-docs


===============================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   Home <self>
   sam_architecture
   getting_started
   api
   credits_license