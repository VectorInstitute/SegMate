===================
Credits and License
===================

Main Contributors
=================
* Vahid Reza Khazaie (https://github.com/vrkh1996)
* Marshall Wang (https://github.com/XkunW)

License
=======
The code in this repository is published under 3-Clause BSD license (see ``LICENSE`` file).